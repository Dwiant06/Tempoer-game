<?php
// db_config.php — XAMPP default: root tanpa password
$mysqli = new mysqli('localhost','root','','tempoer_db');
if ($mysqli->connect_errno) { http_response_code(500); echo 'DB_FAIL'; exit; }
$mysqli->set_charset('utf8mb4');
?>
