<?php
// robot_status.php — heartbeat/status sederhana (tanpa match, tanpa HMAC)
// ACTIVE = default (player), INACTIVE jika freeze aktif; turret INACTIVE jika HP=0 atau is_frozen=1
header('Content-Type: text/plain; charset=utf-8');
require __DIR__.'/db_config.php';
@$mysqli->query("SET time_zone = '+00:00'");

$robot_code = strtolower(trim($_GET['robot_code'] ?? ''));
if (!preg_match('/^[a-z0-9_]{1,32}$/',$robot_code)) { echo "INACTIVE"; exit; }

$isTurret = (strpos($robot_code,'turret_') === 0);
$isPlayer = (preg_match('/^robot_[bo]\d+$/', $robot_code) === 1);

$role = $isTurret ? 'turret' : 'player';
$stmt=$mysqli->prepare("
  INSERT INTO robot_status (robot_code, role, is_frozen, freeze_until, last_ping, health)
  VALUES (?, ?, 0, NULL, UTC_TIMESTAMP(), 100)
  ON DUPLICATE KEY UPDATE last_ping=UTC_TIMESTAMP(), role=VALUES(role)
");
$stmt->bind_param("ss",$robot_code,$role);
$stmt->execute(); $stmt->close();

if ($isPlayer) {
  // Lepas stun jika sudah lewat (HP>0)
  $u1 = $mysqli->prepare("
    UPDATE robot_status
    SET is_frozen=0, freeze_until=NULL
    WHERE robot_code=? AND role='player'
      AND is_frozen=1 AND COALESCE(health,100)>0
      AND freeze_until IS NOT NULL
      AND freeze_until <= UTC_TIMESTAMP()
  ");
  $u1->bind_param("s",$robot_code);
  $u1->execute(); $u1->close();

  // Respawn jika death freeze lewat (HP=0)
  $u2 = $mysqli->prepare("
    UPDATE robot_status
    SET is_frozen=0, freeze_until=NULL, health=100
    WHERE robot_code=? AND role='player'
      AND is_frozen=1 AND COALESCE(health,100)=0
      AND freeze_until IS NOT NULL
      AND freeze_until <= UTC_TIMESTAMP()
  ");
  $u2->bind_param("s",$robot_code);
  $u2->execute(); $u2->close();
}

$stmt = $mysqli->prepare("
  SELECT COALESCE(health,100) AS health,
         COALESCE(is_frozen,0) AS is_frozen,
         (freeze_until > UTC_TIMESTAMP()) AS freeze_active
  FROM robot_status WHERE robot_code=? LIMIT 1
");
$stmt->bind_param("s",$robot_code);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$row) { echo "INACTIVE"; exit; }

$health        = (int)$row['health'];
$is_frozen_col = ((int)$row['is_frozen'] === 1);
$freeze_active = ((int)$row['freeze_active'] === 1);

if ($isTurret) {
  if ($health <= 0 || $is_frozen_col) { echo "INACTIVE"; exit; }
  echo "ACTIVE"; exit;
}

if ($freeze_active) { echo "INACTIVE"; exit; }
echo "ACTIVE"; exit;
?>
