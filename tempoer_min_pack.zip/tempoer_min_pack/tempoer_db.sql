-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 16, 2025 at 03:24 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tempoer_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `robot_auth`
--

CREATE TABLE `robot_auth` (
  `robot_code` varchar(16) NOT NULL,
  `secret_hex` char(64) NOT NULL,
  `status` enum('active','revoked') NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `robot_auth`
--

INSERT INTO `robot_auth` (`robot_code`, `secret_hex`, `status`) VALUES
('robot_b3', 'c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2', 'active'),
('robot_o1', 'd1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `robot_status`
--

CREATE TABLE `robot_status` (
  `robot_code` varchar(100) NOT NULL,
  `is_frozen` tinyint(4) DEFAULT 0,
  `freeze_until` datetime DEFAULT NULL,
  `last_ping` datetime NOT NULL DEFAULT current_timestamp(),
  `health` tinyint(3) UNSIGNED NOT NULL DEFAULT 100,
  `role` enum('player','turret') NOT NULL DEFAULT 'player'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `robot_status`
--

INSERT INTO `robot_status` (`robot_code`, `is_frozen`, `freeze_until`, `last_ping`, `health`, `role`) VALUES
('robot_b3', 0, NULL, '2025-09-16 08:22:49', 100, 'player'),
('robot_o1', 0, NULL, '2025-09-16 08:22:49', 100, 'player');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `robot_auth`
--
ALTER TABLE `robot_auth`
  ADD PRIMARY KEY (`robot_code`),
  ADD KEY `idx_robot_auth_status` (`status`);

--
-- Indexes for table `robot_status`
--
ALTER TABLE `robot_status`
  ADD PRIMARY KEY (`robot_code`),
  ADD KEY `idx_last_ping` (`last_ping`),
  ADD KEY `idx_freeze_until` (`freeze_until`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
