Tempoer Mini Pack — READY TO USE

Folder ini berisi:
- tempoer_db.sql       : struktur + seed 2 robot (robot_b3, robot_o1)
- db_config.php        : koneksi MySQL (XAMPP default)
- robot_status.php     : heartbeat ACTIVE/INACTIVE (freeze-based)
- log_death.php        : terapkan damage, stun, freeze (tanpa match, non-HMAC)
- log_attack.php       : stub untuk menulis serangan ke buffer (TTL 2s)
- action/skullbasher/attack_buffer.json : buffer serangan (kosong)

Langkah cepat:
1) XAMPP → Start Apache & MySQL
2) phpMyAdmin → Import tempoer_db.sql ke database `tempoer_db`
3) Salin semua file ke: C:\xampp\htdocs\tempoer\
   (sertakan folder action\skullbasher\attack_buffer.json)
4) Test di browser:
   - Heartbeat:   http://localhost/tempoer/robot_status.php?robot_code=robot_b3
   - Attack stub: http://localhost/tempoer/log_attack.php?robot_code=robot_o1
   - Apply death: http://localhost/tempoer/log_death.php?robot_code=robot_b3&verbose=1
5) Sesuaikan IP server di firmware robot (contoh: http://192.168.1.x/tempoer/...)
6) Jalankan robot_b3 vs robot_o1; tekan Circle untuk pukul (firmware kirim log_attack)

Catatan:
- HMAC dimatikan agar langsung jalan. Jika ingin HMAC, isi robot_auth dan aktifkan di PHP.
- Buffer serangan berlaku 2 detik — pastikan log_death dipanggil segera setelah log_attack.
