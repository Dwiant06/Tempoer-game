<?php
// log_death.php — minimal: update health/stun/freeze; tanpa match/event log; non-HMAC
header('Content-Type: application/json; charset=utf-8');
require __DIR__ . '/db_config.php';
@$mysqli->query("SET time_zone = '+00:00'");

define('ATTACK_BUFFER_PATH', __DIR__ . '/action/skullbasher/attack_buffer.json');
const DEFAULT_DAMAGE   = 20;
const CRIT_MULTIPLIER  = 1.5;
const STUN_SECONDS     = 2;
const FREEZE_SECONDS   = 20;
const ATTACK_TTL_MS    = 2000;

function team_from_code($code){
  $lc=strtolower($code);
  if(strpos($lc,'robot_b')===0) return 'blue';
  if(strpos($lc,'robot_o')===0) return 'orange';
  return null;
}
function is_player($code){ return preg_match('/^robot_[bo]\d+$/i',$code)===1; }
function json_err($msg,$extra=[]){ echo json_encode(array_merge(["status"=>"error","message"=>$msg],$extra)); exit; }

$robot_code = strtolower(trim($_REQUEST['robot_code'] ?? ''));
$detail     = $_REQUEST['detail']   ?? 'Hit';
$damage_in  = isset($_REQUEST['damage']) ? (int)$_REQUEST['damage'] : DEFAULT_DAMAGE;
$baseDamage = max(0, min(100, $damage_in));
$verbose    = isset($_GET['verbose']) && in_array(strtolower($_GET['verbose']),['1','true','yes'],true);

if ($robot_code === '' || !preg_match('/^[a-z0-9_]{1,32}$/',$robot_code)) json_err("robot_code_invalid");
if (!is_player($robot_code)) json_err("not_a_player_robot");

try {
  $mysqli->begin_transaction();

  // baseline status
  $ins = $mysqli->prepare("
    INSERT IGNORE INTO robot_status (robot_code, health, is_frozen, freeze_until, last_ping, role)
    VALUES (?,100,0,NULL,UTC_TIMESTAMP(),'player')
  ");
  if ($ins){ $ins->bind_param("s",$robot_code); $ins->execute(); $ins->close(); }

  // lock row
  $stmt = $mysqli->prepare("
    SELECT COALESCE(health,100) AS health,
           COALESCE(is_frozen,0) AS is_frozen,
           freeze_until,
           (freeze_until > UTC_TIMESTAMP()) AS freeze_active
    FROM robot_status WHERE robot_code=? FOR UPDATE
  ");
  $stmt->bind_param("s",$robot_code);
  $stmt->execute();
  $st = $stmt->get_result()->fetch_assoc();
  $stmt->close();
  if (!$st) throw new Exception("row_missing");

  $oldH = (int)$st['health'];
  $is_frozen_col = ((int)$st['is_frozen'] === 1);
  $freeze_active = ((int)$st['freeze_active'] === 1);
  $victim_team = team_from_code($robot_code);

  // baca & konsumsi attack buffer (cari serangan tim lawan, TTL<=2s)
  $from_striker = false; $attacker=null; $att_age_ms=null;
  $now_ms = (int)round(microtime(true)*1000);
  if (is_file(ATTACK_BUFFER_PATH) && is_readable(ATTACK_BUFFER_PATH)){
    $fp = fopen(ATTACK_BUFFER_PATH, 'c+');
    if ($fp){
      flock($fp, LOCK_EX); rewind($fp);
      $raw = stream_get_contents($fp);
      $buf = $raw ? json_decode($raw,true) : [];
      if(!is_array($buf)) $buf = [];

      $pick_key = null; $pick_age = PHP_INT_MAX;
      foreach($buf as $k=>$rec){
        $att_team = $rec['team'] ?? null;
        $ts       = (int)($rec['ts_srv'] ?? 0);
        $age      = $now_ms - $ts;
        if ($age < 0 || $age > ATTACK_TTL_MS) continue;
        if ($victim_team && $att_team && $att_team === $victim_team) continue;
        if ($age < $pick_age){ $pick_key=$k; $pick_age=$age; }
      }
      if ($pick_key !== null){
        $from_striker = true;
        $attacker     = $pick_key;
        $att_age_ms   = $pick_age;
        unset($buf[$pick_key]);
      }
      // bersihkan expired
      foreach($buf as $k=>$rec){
        $age = $now_ms - (int)($rec['ts_srv'] ?? 0);
        if ($age > ATTACK_TTL_MS) unset($buf[$k]);
      }
      ftruncate($fp, 0); rewind($fp);
      fwrite($fp, json_encode($buf, JSON_UNESCAPED_SLASHES));
      flock($fp, LOCK_UN); fclose($fp);
    }
  }

  // Gate frozen: jika frozen aktif & bukan dari striker → abaikan
  if ($freeze_active && !$from_striker){
    $mysqli->commit();
    $resp = ["status"=>"frozen","health"=>$oldH];
    echo json_encode($resp); exit;
  }

  if ($oldH <= 0){
    $mysqli->commit();
    echo json_encode(["status"=>"already_dead","health"=>0]); exit;
  }

  // Terapkan damage
  $damage = $from_striker ? (int)round(DEFAULT_DAMAGE * CRIT_MULTIPLIER) : $baseDamage;
  $newH   = max(0, $oldH - $damage);

  $u = $mysqli->prepare("UPDATE robot_status SET health=?, last_ping=UTC_TIMESTAMP() WHERE robot_code=?");
  $u->bind_param("is",$newH,$robot_code);
  $u->execute(); $u->close();

  // Non-lethal dari striker → stun 2s (extend minimal)
  $applied_freeze_str = null; $freeze_until_str = null;
  if ($newH > 0 && $from_striker){
    $uS = $mysqli->prepare("
      UPDATE robot_status
      SET is_frozen=1,
          freeze_until = GREATEST(
            IFNULL(freeze_until, '1970-01-01 00:00:00'),
            DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? SECOND)
          )
      WHERE robot_code=?
    ");
    $stun = STUN_SECONDS;
    $uS->bind_param("is",$stun,$robot_code);
    $uS->execute(); $uS->close();
    if ($verbose){
      $q=$mysqli->prepare("SELECT freeze_until FROM robot_status WHERE robot_code=? LIMIT 1");
      $q->bind_param("s",$robot_code); $q->execute(); $q->bind_result($applied_freeze_str); $q->fetch(); $q->close();
    }
  }

  // Lethal → freeze 20s
  if ($oldH > 0 && $newH===0){
    $u2=$mysqli->prepare("
      UPDATE robot_status
      SET is_frozen=1,
          freeze_until = DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? SECOND)
      WHERE robot_code=?
    ");
    $fz = FREEZE_SECONDS;
    $u2->bind_param("is",$fz,$robot_code);
    $u2->execute(); $u2->close();
    if ($verbose){
      $q=$mysqli->prepare("SELECT freeze_until FROM robot_status WHERE robot_code=? LIMIT 1");
      $q->bind_param("s",$robot_code); $q->execute(); $q->bind_result($freeze_until_str); $q->fetch(); $q->close();
    }
  }

  $mysqli->commit();

  $resp = [
    "status"       => "ok",
    "robot_code"   => $robot_code,
    "source"       => $from_striker ? "pemukul" : "default",
    "damage"       => $damage,
    "health"       => $newH,
    "is_dead"      => (int)($newH<=0),
    "freeze_until" => $newH===0 ? ($freeze_until_str ?? null) : ($applied_freeze_str ?? null)
  ];
  if ($verbose){
    $resp["meta"] = [
      "old_health"   => $oldH,
      "new_health"   => $newH,
      "stun_on_hit"  => ($newH>0 && $from_striker) ? STUN_SECONDS : 0,
      "death_freeze" => ($newH===0) ? FREEZE_SECONDS : 0,
      "attacker"     => $attacker,
      "att_age_ms"   => $att_age_ms
    ];
  }
  echo json_encode($resp);

} catch (Throwable $e){
  $mysqli->rollback();
  json_err("exception", ["error"=>$e->getMessage()]);
}
?>
