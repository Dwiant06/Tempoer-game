<?php
// log_attack.php — stub: tulis serangan ke attack_buffer.json (TTL 2s)
header('Content-Type: application/json; charset=utf-8');
define('BUF', __DIR__.'/action/skullbasher/attack_buffer.json');
define('TTL', 2000);

function team_from_code($c){
  $c=strtolower($c);
  if(strpos($c,'robot_b')===0) return 'blue';
  if(strpos($c,'robot_o')===0) return 'orange';
  return null;
}

$robot_code = strtolower(trim($_GET['robot_code'] ?? ''));
$team      = team_from_code($robot_code) ?? strtolower(trim($_GET['team'] ?? ''));
$now = (int)round(microtime(true)*1000);

if(!$team){ echo json_encode(['status'=>'error','message'=>'team_missing']); exit; }

$buf = [];
if (is_file(BUF) && is_readable(BUF)) {
  $raw = file_get_contents(BUF);
  $buf = $raw ? json_decode($raw, true) : [];
  if (!is_array($buf)) $buf = [];
}
foreach ($buf as $k=>$rec){
  $ts = (int)($rec['ts_srv'] ?? 0);
  if ($now - $ts > TTL) unset($buf[$k]);
}
$key = $robot_code !== '' ? $robot_code : ('atk_'. $now);
$buf[$key] = ['team'=>$team, 'ts_srv'=>$now];

file_put_contents(BUF, json_encode($buf, JSON_UNESCAPED_SLASHES));
echo json_encode(['status'=>'ok','key'=>$key,'team'=>$team]);
?>
